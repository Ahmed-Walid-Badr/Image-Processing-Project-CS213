#pragma once
#include <QColor>
#include <QHash>
#include <QImage>
#include <QMainWindow>
#include <QPair>
#include <QPixmap>
#include <QPushButton>
#include <vector>

#include "imagecanvas.h"

class QFrame;
class QGridLayout;
class QLabel;
class QLineEdit;
class QListWidget;
class QSlider;
class QStackedWidget;
class QToolButton;

// One clickable filter card (number, glyph, name) - painted by hand.
class FilterTile : public QPushButton
{
    Q_OBJECT
public:
    FilterTile(int id, const QString &glyph, QWidget *parent = nullptr);
    int filterId() const { return id_; }
    void setNumberAndLabel(const QString &num, const QString &label) { num_ = num; label_ = label; update(); }

protected:
    void paintEvent(QPaintEvent *) override;

private:
    int id_;
    QString glyph_, num_, label_;
};

// Values collected from a filter's settings dialog.
struct Params
{
    int a = 0, b = 0, c = 0, d = 0;
    bool flag = false;
    double angle = 0;
    QColor color;
    QImage other;
};

class MainWindow : public QMainWindow
{
    Q_OBJECT
public:
    explicit MainWindow(QWidget *parent = nullptr);

protected:
    void dragEnterEvent(QDragEnterEvent *e) override;
    void dropEvent(QDropEvent *e) override;

private:
    struct Entry { QString key; QImage img; QPixmap thumb; };
    struct Section { QWidget *box = nullptr; QLabel *title = nullptr; QLabel *range = nullptr; QGridLayout *grid = nullptr; };

    // UI construction
    void initStrings();
    QString T(const QString &key) const;
    void buildUi();
    QWidget *buildTopBar();
    QWidget *buildSidebar();
    QWidget *buildCenter();
    QWidget *buildRightPanel();
    QWidget *buildFiltersPage();
    QWidget *buildAdjustPage();
    void retranslate();
    void layoutFilters();

    // Image / history
    void openDialog();
    void saveDialog();
    bool loadFile(const QString &path);
    void pushHistory(const QString &key, const QImage &img);
    void gotoHistory(int idx);
    void showCurrent();
    void refreshHistory();
    void clearHistory();
    void undo();
    void redo();
    void updateButtons();
    void updateInfo();

    // Filters
    void selectFilter(int id);
    void applyPending();
    void cancelPending(bool restoreCanvas = true);
    void syncTiles();
    bool askParams(int id, Params &p);
    QImage applyFilter(int id, const Params &p) const;
    void onAdjustChanged();
    void applyAdjust();

    // state
    bool ar_ = true;
    QImage original_;
    std::vector<Entry> history_;
    std::vector<Entry> redo_;
    int histIdx_ = -1;
    QString fileName_, format_;
    QString query_;
    QHash<QString, QPair<QString, QString>> strings_;

    // widgets
    ImageCanvas *canvas_ = nullptr;
    QLabel *wsLbl_ = nullptr, *edLbl_ = nullptr;
    QPushButton *langBtn_ = nullptr, *openBtn_ = nullptr, *saveBtn_ = nullptr;
    QToolButton *undoBtn_ = nullptr, *redoBtn_ = nullptr;
    QToolButton *sideFilters_ = nullptr, *sideHelp_ = nullptr;
    QLabel *sideLocal_ = nullptr;
    QPushButton *compareBtn_ = nullptr, *zoom100Btn_ = nullptr, *fitBtn_ = nullptr;
    QLabel *zoomLbl_ = nullptr, *infoLbl_ = nullptr;
    QSlider *zoomSlider_ = nullptr;
    QFrame *histFrame_ = nullptr, *rightPanel_ = nullptr;
    QLabel *histTitle_ = nullptr, *histBadge_ = nullptr, *histHint_ = nullptr;
    QPushButton *histClear_ = nullptr;
    QListWidget *histList_ = nullptr;

    QStackedWidget *stack_ = nullptr;
    QPushButton *filtersTab_ = nullptr, *adjustTab_ = nullptr;
    QLabel *fTitle_ = nullptr, *fSub_ = nullptr, *tipLbl_ = nullptr;
    QLineEdit *search_ = nullptr;
    Section sec_[3];
    std::vector<FilterTile *> tiles_;

    // pending (previewed, not yet applied) filter
    int pendingId_ = 0;
    Params pendingParams_;
    QImage pendingImg_;
    QFrame *pendingBar_ = nullptr;
    QLabel *pendingLbl_ = nullptr;
    QPushButton *pendApply_ = nullptr, *pendCancel_ = nullptr;

    QLabel *aTitle_ = nullptr, *aSub_ = nullptr, *aBright_ = nullptr, *aContrast_ = nullptr, *bVal_ = nullptr, *cVal_ = nullptr;
    QSlider *brightSlider_ = nullptr, *contrastSlider_ = nullptr;
    QPushButton *adjApply_ = nullptr, *adjReset_ = nullptr;
};
