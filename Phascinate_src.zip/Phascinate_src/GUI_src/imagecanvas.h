#pragma once
#include <QImage>
#include <QMouseEvent>
#include <QPainter>
#include <QPainterPath>
#include <QPixmap>
#include <QTimer>
#include <QWheelEvent>
#include <QWidget>
#include <algorithm>

// Central preview area: dotted dark background, zoom/pan, before/after compare.
class ImageCanvas : public QWidget
{
    Q_OBJECT
public:
    explicit ImageCanvas(QWidget *parent = nullptr) : QWidget(parent)
    {
        setMinimumSize(320, 220);
        setCursor(Qt::PointingHandCursor);
        toastTimer_.setSingleShot(true);
        connect(&toastTimer_, &QTimer::timeout, this, [this] { toast_.clear(); update(); });
    }

    bool hasImage() const { return !editedPix_.isNull(); }
    double zoom() const { return zoom_; }
    bool isFit() const { return fit_; }

    void setTexts(const QString &empty, const QString &badge, const QString &orig, const QString &edited)
    {
        emptyText_ = empty; badgeText_ = badge; origText_ = orig; editedText_ = edited;
        update();
    }
    void setFileName(const QString &n) { fileName_ = n; update(); }
    void setOriginal(const QImage &img) { origPix_ = QPixmap::fromImage(img); update(); }

    void setEdited(const QImage &img)
    {
        const bool sizeChanged = img.size() != editedSize_;
        editedPix_ = QPixmap::fromImage(img);
        editedSize_ = img.size();
        setCursor(Qt::ArrowCursor);
        if (sizeChanged) fit(); else update();
    }

    void setCompare(bool on) { compare_ = on; update(); }

    void showToast(const QString &text, int ms = 2200)
    {
        toast_ = text;
        toastTimer_.start(ms);
        update();
    }

public slots:
    void fit()
    {
        fit_ = true;
        pan_ = QPointF();
        if (hasImage()) {
            double zx = (width() - 80.0) / editedSize_.width();
            double zy = (height() - 80.0) / editedSize_.height();
            zoom_ = std::clamp(std::min(zx, zy), 0.02, 1.0);
        } else {
            zoom_ = 1.0;
        }
        emit zoomChanged(zoom_);
        update();
    }

    void setZoom(double z)
    {
        zoom_ = std::clamp(z, 0.05, 8.0);
        fit_ = false;
        emit zoomChanged(zoom_);
        update();
    }

signals:
    void zoomChanged(double zoom);
    void clicked();   // pressed while no image is loaded

protected:
    QRectF imageRect() const
    {
        QSizeF s(editedSize_.width() * zoom_, editedSize_.height() * zoom_);
        QPointF c(width() / 2.0, height() / 2.0);
        c += pan_;
        return QRectF(c.x() - s.width() / 2, c.y() - s.height() / 2, s.width(), s.height());
    }

    void drawChip(QPainter &p, const QRectF &r, const QString &text, bool dot)
    {
        p.setPen(QColor("#252e3b"));
        p.setBrush(QColor(14, 19, 26, 230));
        p.drawRoundedRect(r, 8, 8);
        QRectF t = r.adjusted(dot ? 26 : 12, 0, -12, 0);
        if (dot) {
            p.setPen(Qt::NoPen);
            p.setBrush(QColor("#5aa9ff"));
            p.drawEllipse(QPointF(r.left() + 15, r.center().y()), 3.5, 3.5);
        }
        p.setPen(QColor("#c6cfdb"));
        p.drawText(t, Qt::AlignVCenter | Qt::AlignLeft, text);
    }

    void paintEvent(QPaintEvent *) override
    {
        QPainter p(this);
        p.setRenderHint(QPainter::Antialiasing);
        p.fillRect(rect(), QColor("#0b0f15"));

        // dotted grid
        p.setPen(QPen(QColor("#18202a"), 2));
        for (int x = 14; x < width(); x += 24)
            for (int y = 14; y < height(); y += 24) p.drawPoint(x, y);

        QFont base = font();
        base.setPixelSize(12);
        p.setFont(base);
        QFontMetrics fm(base);

        if (!hasImage()) {
            p.setPen(QPen(QColor("#2b3646"), 2, Qt::DashLine));
            p.setBrush(Qt::NoBrush);
            QRectF box(0, 0, 360, 190);
            box.moveCenter(QPointF(width() / 2.0, height() / 2.0));
            p.drawRoundedRect(box, 18, 18);
            QFont big = base; big.setPixelSize(44);
            p.setFont(big);
            p.setPen(QColor("#b8f45c"));
            p.drawText(QRectF(box.left(), box.top() + 30, box.width(), 60), Qt::AlignCenter, "+");
            QFont mid = base; mid.setPixelSize(15);
            p.setFont(mid);
            p.setPen(QColor("#9aa5b3"));
            p.drawText(QRectF(box.left(), box.top() + 100, box.width(), 40), Qt::AlignCenter, emptyText_);
        } else {
            const QRectF r = imageRect();
            QPainterPath clip;
            clip.addRoundedRect(r, 6, 6);
            p.save();
            p.setClipPath(clip);
            p.setRenderHint(QPainter::SmoothPixmapTransform, zoom_ < 2.0);
            p.drawPixmap(r, editedPix_, QRectF(editedPix_.rect()));
            if (compare_ && !origPix_.isNull()) {
                const double sx = r.left() + split_ * r.width();
                p.setClipRect(QRectF(r.left(), r.top(), sx - r.left(), r.height()));
                p.drawPixmap(r, origPix_, QRectF(origPix_.rect()));
            }
            p.restore();

            if (compare_) {
                const double sx = r.left() + split_ * r.width();
                p.setPen(QPen(QColor("#b8f45c"), 2));
                p.drawLine(QPointF(sx, r.top()), QPointF(sx, r.bottom()));
                p.setBrush(QColor("#b8f45c"));
                p.setPen(Qt::NoPen);
                p.drawEllipse(QPointF(sx, r.center().y()), 11, 11);
                p.setPen(QColor("#10170a"));
                p.drawText(QRectF(sx - 11, r.center().y() - 11, 22, 22), Qt::AlignCenter, QStringLiteral("⇆"));
                p.setFont(base);
                QRectF c1(r.left() + 10, r.top() + 10, fm.horizontalAdvance(origText_) + 24, 26);
                QRectF c2(r.right() - fm.horizontalAdvance(editedText_) - 34, r.top() + 10,
                          fm.horizontalAdvance(editedText_) + 24, 26);
                drawChip(p, c1, origText_, false);
                drawChip(p, c2, editedText_, false);
            }

            // file chip (top-right)
            if (!fileName_.isEmpty()) {
                QRectF chip(0, 16, fm.horizontalAdvance(fileName_) + 40, 32);
                chip.moveRight(width() - 16);
                drawChip(p, chip, fileName_, true);
            }
        }

        // badge (top-left)
        if (!badgeText_.isEmpty()) {
            QFont s = base; s.setPixelSize(11);
            p.setFont(s);
            QRectF chip(16, 16, QFontMetrics(s).horizontalAdvance(badgeText_) + 26, 30);
            drawChip(p, chip, badgeText_, false);
        }

        // toast
        if (!toast_.isEmpty()) {
            p.setFont(base);
            QRectF t(0, 0, fm.horizontalAdvance(toast_) + 44, 38);
            t.moveCenter(QPointF(width() / 2.0, height() - 40));
            p.setPen(Qt::NoPen);
            p.setBrush(QColor("#b8f45c"));
            p.drawRoundedRect(t, 19, 19);
            p.setPen(QColor("#10170a"));
            p.drawText(t, Qt::AlignCenter, toast_);
        }
    }

    void mousePressEvent(QMouseEvent *e) override
    {
        if (!hasImage()) { if (e->button() == Qt::LeftButton) emit clicked(); return; }
        if (e->button() != Qt::LeftButton) return;
        if (compare_) updateSplit(e->pos().x());
        else { dragging_ = true; last_ = e->pos(); setCursor(Qt::ClosedHandCursor); }
    }
    void mouseMoveEvent(QMouseEvent *e) override
    {
        if (!(e->buttons() & Qt::LeftButton)) return;
        if (compare_) updateSplit(e->pos().x());
        else if (dragging_) {
            pan_ += QPointF(e->pos() - last_);
            last_ = e->pos();
            update();
        }
    }
    void mouseReleaseEvent(QMouseEvent *) override { dragging_ = false; setCursor(hasImage() ? Qt::ArrowCursor : Qt::PointingHandCursor); }
    void mouseDoubleClickEvent(QMouseEvent *) override { fit(); }
    void wheelEvent(QWheelEvent *e) override
    {
        if (!hasImage()) return;
        setZoom(zoom_ * (e->angleDelta().y() > 0 ? 1.1 : 1.0 / 1.1));
    }
    void resizeEvent(QResizeEvent *) override { if (fit_) fit(); }

private:
    void updateSplit(int x)
    {
        const QRectF r = imageRect();
        split_ = std::clamp((x - r.left()) / std::max(1.0, r.width()), 0.0, 1.0);
        update();
    }

    QPixmap editedPix_, origPix_;
    QSize editedSize_;
    double zoom_ = 1.0, split_ = 0.5;
    bool fit_ = true, compare_ = false, dragging_ = false;
    QPointF pan_;
    QPoint last_;
    QString fileName_, emptyText_, badgeText_, origText_, editedText_, toast_;
    QTimer toastTimer_;
};
