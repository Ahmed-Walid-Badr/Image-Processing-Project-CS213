#pragma once
// Hand-drawn vector icons (no icon fonts needed) - one per filter plus UI icons.
//  1..18 = filters, 0 = adjust sliders, 101 = filters (sparkles), 102 = help
#include <QApplication>
#include <QIcon>
#include <QPainter>
#include <QPainterPath>
#include <QPixmap>
#include <cmath>

namespace Icons {

inline void draw(QPainter &p, int id, const QRectF &r, const QColor &c)
{
    const double kPi = 3.14159265358979323846;
    p.save();
    p.setRenderHint(QPainter::Antialiasing);
    p.translate(r.topLeft());
    p.scale(r.width(), r.height());
    const QPen pen(c, 0.075, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin);
    p.setPen(pen);
    p.setBrush(Qt::NoBrush);
    QColor soft = c;
    soft.setAlphaF(0.35);
    auto line = [&](double x1, double y1, double x2, double y2) { p.drawLine(QPointF(x1, y1), QPointF(x2, y2)); };
    auto circle = [&](double cx, double cy, double rad) { p.drawEllipse(QPointF(cx, cy), rad, rad); };

    switch (id) {
    case 0: // adjust sliders
        line(.2, .12, .2, .88); line(.5, .12, .5, .88); line(.8, .12, .8, .88);
        p.setBrush(c);
        circle(.2, .62, .1); circle(.5, .34, .1); circle(.8, .55, .1);
        break;
    case 1: { // greyscale ramp
        QLinearGradient g(0, 0, 1, 0);
        g.setColorAt(0, QColor(c.red(), c.green(), c.blue(), 25));
        g.setColorAt(1, c);
        p.setBrush(g);
        p.drawRoundedRect(QRectF(.12, .16, .76, .68), .14, .14);
        break;
    }
    case 2: // black & white
        circle(.5, .5, .37);
        p.setBrush(c);
        p.drawPie(QRectF(.13, .13, .74, .74), 90 * 16, 180 * 16);
        break;
    case 3: // invert
        p.setBrush(c);
        circle(.37, .5, .27);
        p.setBrush(Qt::NoBrush);
        circle(.63, .5, .27);
        break;
    case 4: // frame
        p.drawRoundedRect(QRectF(.1, .1, .8, .8), .1, .1);
        p.drawRect(QRectF(.3, .3, .4, .4));
        break;
    case 5: { // flip
        p.setBrush(c);
        p.drawPolygon(QPolygonF({QPointF(.08, .8), QPointF(.4, .8), QPointF(.4, .2)}));
        p.setBrush(Qt::NoBrush);
        p.drawPolygon(QPolygonF({QPointF(.92, .8), QPointF(.6, .8), QPointF(.6, .2)}));
        QPen d(c, 0.05, Qt::DashLine, Qt::RoundCap);
        p.setPen(d);
        line(.5, .08, .5, .92);
        break;
    }
    case 6: { // rotate
        const double cx = .5, cy = .5, R = .32;
        const int a0 = 70, span = 270;
        p.drawArc(QRectF(cx - R, cy - R, 2 * R, 2 * R), a0 * 16, span * 16);
        const double th = (a0 + span) * kPi / 180.0;
        const QPointF e(cx + R * std::cos(th), cy - R * std::sin(th));
        const QPointF t(-std::sin(th), -std::cos(th)), n(std::cos(th), -std::sin(th));
        p.setBrush(c);
        p.drawPolygon(QPolygonF({e + t * .14, e + n * .11, e - n * .11}));
        break;
    }
    case 7: // brightness sun
        circle(.5, .5, .17);
        for (int i = 0; i < 8; ++i) {
            double a = i * kPi / 4;
            line(.5 + .29 * std::cos(a), .5 + .29 * std::sin(a), .5 + .43 * std::cos(a), .5 + .43 * std::sin(a));
        }
        break;
    case 8: // resize
        line(.22, .78, .78, .22);
        p.drawPolyline(QPolygonF({QPointF(.52, .2), QPointF(.8, .2), QPointF(.8, .48)}));
        p.drawPolyline(QPolygonF({QPointF(.48, .8), QPointF(.2, .8), QPointF(.2, .52)}));
        break;
    case 9: // merge
        p.drawRoundedRect(QRectF(.12, .12, .48, .48), .08, .08);
        p.setBrush(soft);
        p.drawRoundedRect(QRectF(.4, .4, .48, .48), .08, .08);
        break;
    case 10: { // edges
        QPen d(c, 0.055, Qt::DashLine, Qt::RoundCap);
        p.setPen(d);
        p.drawRoundedRect(QRectF(.1, .1, .8, .8), .1, .1);
        p.setPen(pen);
        circle(.5, .5, .22);
        break;
    }
    case 11: // crop
        p.drawPolyline(QPolygonF({QPointF(.3, .08), QPointF(.3, .7), QPointF(.92, .7)}));
        p.drawPolyline(QPolygonF({QPointF(.08, .3), QPointF(.7, .3), QPointF(.7, .92)}));
        break;
    case 12: // blur
        p.setPen(Qt::NoPen);
        p.setBrush(QColor(c.red(), c.green(), c.blue(), 40));
        circle(.5, .5, .42);
        p.setBrush(QColor(c.red(), c.green(), c.blue(), 100));
        circle(.5, .5, .29);
        p.setBrush(c);
        circle(.5, .5, .15);
        break;
    case 13: // sunlight: rising sun
        line(.08, .7, .92, .7);
        p.drawArc(QRectF(.3, .5, .4, .4), 0, 180 * 16);
        for (int i = 0; i < 5; ++i) {
            double a = i * kPi / 4;
            line(.5 + .26 * std::cos(a), .7 - .26 * std::sin(a), .5 + .4 * std::cos(a), .7 - .4 * std::sin(a));
        }
        line(.3, .84, .7, .84);
        break;
    case 14: // old TV
        p.drawRoundedRect(QRectF(.1, .3, .8, .58), .08, .08);
        line(.5, .3, .34, .1); line(.5, .3, .66, .1);
        line(.22, .47, .6, .47); line(.22, .59, .6, .59); line(.22, .71, .6, .71);
        p.setBrush(c);
        circle(.77, .52, .04);
        break;
    case 15: { // purple night
        QPainterPath a, b;
        a.addEllipse(QPointF(.42, .54), .3, .3);
        b.addEllipse(QPointF(.56, .44), .26, .26);
        p.setPen(Qt::NoPen);
        p.setBrush(c);
        p.drawPath(a.subtracted(b));
        p.setPen(QPen(c, 0.06, Qt::SolidLine, Qt::RoundCap));
        line(.78, .14, .78, .36); line(.67, .25, .89, .25);
        line(.84, .62, .84, .74); line(.78, .68, .9, .68);
        break;
    }
    case 16: { // infrared: eye
        QPainterPath eye;
        eye.moveTo(.06, .5);
        eye.quadTo(.5, .08, .94, .5);
        eye.quadTo(.5, .92, .06, .5);
        p.drawPath(eye);
        p.setBrush(c);
        circle(.5, .5, .13);
        break;
    }
    case 17: // skew
        p.setBrush(soft);
        p.drawPolygon(QPolygonF({QPointF(.3, .24), QPointF(.92, .24), QPointF(.7, .76), QPointF(.08, .76)}));
        break;
    case 18: { // oil painting: palette
        QPainterPath pal;
        pal.addEllipse(QRectF(.08, .16, .84, .68));
        p.drawPath(pal);
        circle(.66, .66, .07);
        p.setPen(Qt::NoPen);
        p.setBrush(c);
        circle(.3, .46, .06); circle(.46, .32, .06); circle(.64, .36, .06); circle(.28, .64, .06);
        break;
    }
    case 101: { // sparkles
        auto spark = [&](double cx, double cy, double s) {
            QPainterPath q;
            q.moveTo(cx, cy - s);
            q.quadTo(cx, cy, cx + s, cy);
            q.quadTo(cx, cy, cx, cy + s);
            q.quadTo(cx, cy, cx - s, cy);
            q.quadTo(cx, cy, cx, cy - s);
            p.drawPath(q);
        };
        p.setBrush(c);
        p.setPen(QPen(c, 0.04, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
        spark(.42, .58, .32);
        spark(.78, .22, .15);
        break;
    }
    case 102: // help
        circle(.5, .5, .38);
        line(.5, .46, .5, .7);
        p.setBrush(c);
        p.setPen(Qt::NoPen);
        circle(.5, .3, .045);
        break;
    }
    p.restore();
}

inline QPixmap pixmap(int id, int px, const QColor &c)
{
    const qreal dpr = qApp->devicePixelRatio();
    QPixmap pm(int(px * dpr), int(px * dpr));
    pm.setDevicePixelRatio(dpr);
    pm.fill(Qt::transparent);
    QPainter p(&pm);
    draw(p, id, QRectF(0, 0, px, px), c);
    return pm;
}

inline QIcon icon(int id, int px, const QColor &off, const QColor &on)
{
    QIcon ic;
    ic.addPixmap(pixmap(id, px, off), QIcon::Normal, QIcon::Off);
    ic.addPixmap(pixmap(id, px, on), QIcon::Normal, QIcon::On);
    return ic;
}

} // namespace Icons
