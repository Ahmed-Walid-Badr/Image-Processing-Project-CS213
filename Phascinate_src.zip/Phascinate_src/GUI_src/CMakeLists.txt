cmake_minimum_required(VERSION 3.16)
project(Phascinate VERSION 1.0 LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_AUTOMOC ON)

# Source files contain Arabic UTF-8 text
if(MSVC)
    add_compile_options(/utf-8)
endif()

# Works with Qt 6 (preferred) or Qt 5
find_package(QT NAMES Qt6 Qt5 REQUIRED COMPONENTS Widgets)
find_package(Qt${QT_VERSION_MAJOR} REQUIRED COMPONENTS Widgets)

add_executable(Phascinate
    main.cpp
    mainwindow.h
    mainwindow.cpp
    imagecanvas.h
    filters.h
    icons.h
)

target_link_libraries(Phascinate PRIVATE Qt${QT_VERSION_MAJOR}::Widgets)

set_target_properties(Phascinate PROPERTIES
    WIN32_EXECUTABLE ON
    MACOSX_BUNDLE ON
)
