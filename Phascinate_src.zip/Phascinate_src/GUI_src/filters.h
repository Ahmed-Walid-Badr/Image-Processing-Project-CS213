#pragma once
// ============================================================================
//  Phascinate - the 18 image filters, ported from the original console project
//  (Source_Code.cpp) to work on QImage (Format_RGB888).  Every filter takes an
//  image and returns a NEW image, which makes undo/redo trivial.
// ============================================================================
#include <QColor>
#include <QImage>
#include <QTransform>
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <vector>

namespace Filters {

constexpr double kPi = 3.14159265358979323846;

inline QImage rgb(const QImage &src)
{
    return src.format() == QImage::Format_RGB888 ? src : src.convertToFormat(QImage::Format_RGB888);
}

inline uchar clamp8(int v) { return static_cast<uchar>(v < 0 ? 0 : (v > 255 ? 255 : v)); }

// ---- 1: Greyscale ---------------------------------------------------------
inline QImage greyscale(const QImage &src)
{
    QImage o = rgb(src);
    for (int y = 0; y < o.height(); ++y) {
        uchar *p = o.scanLine(y);
        for (int x = 0; x < o.width(); ++x, p += 3) {
            uchar a = static_cast<uchar>((p[0] + p[1] + p[2]) / 3);
            p[0] = p[1] = p[2] = a;
        }
    }
    return o;
}

// ---- 2: Black & White -----------------------------------------------------
inline QImage blackWhite(const QImage &src)
{
    QImage o = rgb(src);
    for (int y = 0; y < o.height(); ++y) {
        uchar *p = o.scanLine(y);
        for (int x = 0; x < o.width(); ++x, p += 3) {
            uchar v = ((p[0] + p[1] + p[2]) / 3) >= 128 ? 255 : 0;
            p[0] = p[1] = p[2] = v;
        }
    }
    return o;
}

// ---- 3: Invert ------------------------------------------------------------
inline QImage invert(const QImage &src)
{
    QImage o = rgb(src);
    for (int y = 0; y < o.height(); ++y) {
        uchar *p = o.scanLine(y);
        for (int x = 0; x < o.width() * 3; ++x) p[x] = static_cast<uchar>(255 - p[x]);
    }
    return o;
}

// ---- 4: Frame (simple / fancy) -------------------------------------------
inline QImage frame(const QImage &src, bool fancy, int t, const QColor &c)
{
    QImage o = rgb(src);
    const int w = o.width(), h = o.height();
    const int gap = t / 2, inner = 2;
    const int start = t + gap, endW = w - (t + gap), endH = h - (t + gap);
    for (int y = 0; y < h; ++y) {
        uchar *row = o.scanLine(y);
        for (int x = 0; x < w; ++x) {
            uchar *p = row + x * 3;
            if (x < t || x >= w - t || y < t || y >= h - t) {
                p[0] = static_cast<uchar>(c.red());
                p[1] = static_cast<uchar>(c.green());
                p[2] = static_cast<uchar>(c.blue());
            }
            if (fancy) {
                if ((x >= start && x < start + inner) || (x < endW && x >= endW - inner) ||
                    (y >= start && y < start + inner) || (y < endH && y >= endH - inner))
                    p[0] = p[1] = p[2] = 255;
            }
        }
    }
    return o;
}

// ---- 5: Flip --------------------------------------------------------------
inline QImage flip(const QImage &src, bool horizontal)
{
    return rgb(src).mirrored(horizontal, !horizontal);
}

// ---- 6: Rotate (90 / 180 / 270, clockwise) -------------------------------
inline QImage rotate(const QImage &src, int degrees)
{
    QImage o = rgb(src);
    if (degrees == 180) return o.mirrored(true, true);
    QTransform t;
    t.rotate(degrees);
    return o.transformed(t, Qt::FastTransformation).convertToFormat(QImage::Format_RGB888);
}

// ---- 7: Darken / Lighten --------------------------------------------------
inline QImage brightnessLevel(const QImage &src, bool lighten, int level)
{
    QImage o = rgb(src);
    const float f = lighten ? 1.0f + level / 100.0f : 1.0f - level / 100.0f;
    uchar lut[256];
    for (int i = 0; i < 256; ++i) lut[i] = clamp8(static_cast<int>(i * f));
    for (int y = 0; y < o.height(); ++y) {
        uchar *p = o.scanLine(y);
        for (int x = 0; x < o.width() * 3; ++x) p[x] = lut[p[x]];
    }
    return o;
}

// ---- 8: Resize ------------------------------------------------------------
inline QImage resize(const QImage &src, int Width, int Height)
{
    QImage s = rgb(src);
    QImage r(Width, Height, QImage::Format_RGB888);
    for (int y = 0; y < Height; ++y) {
        uchar *d = r.scanLine(y);
        const uchar *row = s.constScanLine(static_cast<int>(static_cast<long long>(y) * s.height() / Height));
        for (int x = 0; x < Width; ++x) {
            const uchar *p = row + static_cast<int>(static_cast<long long>(x) * s.width() / Width) * 3;
            d[x * 3] = p[0]; d[x * 3 + 1] = p[1]; d[x * 3 + 2] = p[2];
        }
    }
    return r;
}

// ---- 9: Merge (average of two images) ------------------------------------
inline QImage merge(const QImage &a0, const QImage &b0, bool biggest)
{
    QImage a = rgb(a0), b = rgb(b0);
    const int W = biggest ? std::max(a.width(), b.width()) : std::min(a.width(), b.width());
    const int H = biggest ? std::max(a.height(), b.height()) : std::min(a.height(), b.height());
    QImage r(W, H, QImage::Format_RGB888);
    r.fill(Qt::black);
    for (int y = 0; y < H; ++y) {
        uchar *d = r.scanLine(y);
        const bool rowA = y < a.height(), rowB = y < b.height();
        const uchar *ra = rowA ? a.constScanLine(y) : nullptr;
        const uchar *rb = rowB ? b.constScanLine(y) : nullptr;
        for (int x = 0; x < W; ++x) {
            const bool inA = rowA && x < a.width(), inB = rowB && x < b.width();
            for (int k = 0; k < 3; ++k) {
                if (inA && inB) d[x * 3 + k] = static_cast<uchar>((ra[x * 3 + k] + rb[x * 3 + k]) / 2);
                else if (inA)   d[x * 3 + k] = ra[x * 3 + k];
                else if (inB)   d[x * 3 + k] = rb[x * 3 + k];
            }
        }
    }
    return r;
}

// ---- 10: Detect edges (white background, black edges) --------------------
inline QImage edges(const QImage &src, int threshold = 40)
{
    QImage s = rgb(src);
    QImage o(s.width(), s.height(), QImage::Format_RGB888);
    o.fill(Qt::white);
    auto avg = [](const uchar *p) { return (p[0] + p[1] + p[2]) / 3; };
    for (int y = 0; y < s.height() - 1; ++y) {
        const uchar *r0 = s.constScanLine(y), *r1 = s.constScanLine(y + 1);
        uchar *d = o.scanLine(y);
        for (int x = 0; x < s.width() - 1; ++x) {
            int a = avg(r0 + x * 3), right = avg(r0 + (x + 1) * 3), down = avg(r1 + x * 3);
            if (std::abs(right - a) >= threshold || std::abs(down - a) >= threshold)
                d[x * 3] = d[x * 3 + 1] = d[x * 3 + 2] = 0;
        }
    }
    return o;
}

// ---- 11: Crop -------------------------------------------------------------
inline QImage crop(const QImage &src, int x, int y, int w, int h)   // x, y are 1-based like the original
{
    QImage s = rgb(src);
    x = std::clamp(x, 1, s.width());
    y = std::clamp(y, 1, s.height());
    if (x + (w - 1) > s.width()) w = s.width() - x;
    if (y + (h - 1) > s.height()) h = s.height() - y;
    w = std::max(1, w);
    h = std::max(1, h);
    return s.copy(x - 1, y - 1, w, h);
}

// ---- 12: Blur (repeated 3x3 box blur) ------------------------------------
inline QImage blur(const QImage &src, int passes)
{
    QImage a = rgb(src);
    if (a.width() < 3 || a.height() < 3) return a;
    QImage b = a;
    b.detach();
    const int w = a.width(), h = a.height();
    for (int pass = 0; pass < passes; ++pass) {
        for (int y = 1; y < h - 1; ++y) {
            const uchar *r0 = a.constScanLine(y - 1), *r1 = a.constScanLine(y), *r2 = a.constScanLine(y + 1);
            uchar *d = b.scanLine(y);
            for (int x = 1; x < w - 1; ++x) {
                for (int k = 0; k < 3; ++k) {
                    int sum = r0[(x - 1) * 3 + k] + r0[x * 3 + k] + r0[(x + 1) * 3 + k] +
                              r1[(x - 1) * 3 + k] + r1[x * 3 + k] + r1[(x + 1) * 3 + k] +
                              r2[(x - 1) * 3 + k] + r2[x * 3 + k] + r2[(x + 1) * 3 + k];
                    d[x * 3 + k] = static_cast<uchar>(sum / 9);
                }
            }
        }
        std::swap(a, b);
    }
    return a;
}

// ---- 13: Sunlight (warm tint) --------------------------------------------
inline QImage sunlight(const QImage &src)
{
    QImage o = rgb(src);
    for (int y = 0; y < o.height(); ++y) {
        uchar *p = o.scanLine(y);
        for (int x = 0; x < o.width(); ++x, p += 3) {
            for (int k = 0; k < 3; ++k) {          // same loop as the original code
                int Red = p[k] + 20;
                int Green = p[k] + 10;
                int Blue = p[k] - 10;
                Red = std::min(255, Red);
                Green = std::min(255, Green);
                Blue = std::max(0, Blue);
                p[0] = static_cast<uchar>(Red);
                p[1] = static_cast<uchar>(Green);
                p[2] = static_cast<uchar>(Blue);
            }
        }
    }
    return o;
}

// ---- 14: Old TV (black scan lines) ---------------------------------------
inline QImage oldTV(const QImage &src)
{
    QImage o = rgb(src);
    for (int y = 1; y < o.height(); y += 2) {
        uchar *p = o.scanLine(y);
        std::fill(p, p + o.width() * 3, uchar(0));
    }
    return o;
}

// ---- 15: Purple -----------------------------------------------------------
inline QImage purple(const QImage &src)
{
    QImage o = rgb(src);
    for (int y = 0; y < o.height(); ++y) {
        uchar *p = o.scanLine(y);
        for (int x = 0; x < o.width(); ++x, p += 3) p[1] = static_cast<uchar>(p[1] * 0.64);
    }
    return o;
}

// ---- 16: Infrared ---------------------------------------------------------
inline QImage infrared(const QImage &src)
{
    QImage o = rgb(src);
    for (int y = 0; y < o.height(); ++y) {
        uchar *p = o.scanLine(y);
        for (int x = 0; x < o.width(); ++x, p += 3) {
            p[0] = 255;
            p[1] = static_cast<uchar>(255 - p[1]);
            p[2] = static_cast<uchar>(255 - p[2]);
        }
    }
    return o;
}

// ---- 17: Skew -------------------------------------------------------------
inline QImage skew(const QImage &src, double angleDeg)
{
    QImage s = rgb(src);
    const int w = s.width(), h = s.height();
    const double t = std::tan(angleDeg * kPi / 180.0) * 0.5;
    const int add = std::abs(static_cast<int>(std::floor(h * t)));
    const int offset = t < 0 ? add : 0;
    const int nw = w + add;
    QImage r(nw, h, QImage::Format_RGB888);
    r.fill(Qt::white);
    for (int y = 0; y < h; ++y) {
        const int shift = static_cast<int>(y * t) + offset;
        const uchar *sp = s.constScanLine(y);
        uchar *dp = r.scanLine(y);
        for (int x = 0; x < w; ++x) {
            int nx = x + shift;
            if (nx < 0 || nx >= nw) continue;
            dp[nx * 3] = sp[x * 3];
            dp[nx * 3 + 1] = sp[x * 3 + 1];
            dp[nx * 3 + 2] = sp[x * 3 + 2];
        }
    }
    return r;
}

// ---- 18: Oil painting -----------------------------------------------------
inline QImage oilPainting(const QImage &src, int radius = 4, int levels = 20)
{
    QImage o = rgb(src);
    o.detach();
    const int w = o.width(), h = o.height();
    int count[64], sumR[64], sumG[64], sumB[64];
    for (int x = 0; x < w; ++x) {
        for (int y = 0; y < h; ++y) {
            std::fill_n(count, levels, 0);
            std::fill_n(sumR, levels, 0);
            std::fill_n(sumG, levels, 0);
            std::fill_n(sumB, levels, 0);
            for (int dx = -radius; dx <= radius; ++dx) {
                for (int dy = -radius; dy <= radius; ++dy) {
                    int nx = x + dx, ny = y + dy;
                    if (nx < 0 || nx >= w || ny < 0 || ny >= h) continue;
                    const uchar *p = o.constScanLine(ny) + nx * 3;
                    int r = p[0], g = p[1], b = p[2];
                    int bin = ((r + g + b) / 3) * levels / 256;
                    count[bin]++;
                    sumR[bin] += r; sumG[bin] += g; sumB[bin] += b;
                }
            }
            int best = 0;
            for (int i = 1; i < levels; ++i)
                if (count[i] > count[best]) best = i;
            uchar *d = o.scanLine(y) + x * 3;
            d[0] = static_cast<uchar>(sumR[best] / count[best]);
            d[1] = static_cast<uchar>(sumG[best] / count[best]);
            d[2] = static_cast<uchar>(sumB[best] / count[best]);
        }
    }
    return o;
}

// ---- Extra: Adjust (brightness + contrast, -100..100) --------------------
inline QImage adjust(const QImage &src, int brightness, int contrast)
{
    QImage o = rgb(src);
    const double f = contrast >= 0 ? 1.0 + contrast / 50.0 : 1.0 + contrast / 100.0;
    uchar lut[256];
    for (int i = 0; i < 256; ++i)
        lut[i] = clamp8(static_cast<int>((i - 128) * f + 128 + brightness * 1.28));
    for (int y = 0; y < o.height(); ++y) {
        uchar *p = o.scanLine(y);
        for (int x = 0; x < o.width() * 3; ++x) p[x] = lut[p[x]];
    }
    return o;
}

} // namespace Filters
