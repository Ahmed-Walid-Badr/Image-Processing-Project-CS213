#include "mainwindow.h"
#include "filters.h"
#include "icons.h"

#include <QApplication>
#include <QCheckBox>
#include <QColorDialog>
#include <QComboBox>
#include <QDialog>
#include <QDialogButtonBox>
#include <QDoubleSpinBox>
#include <QDragEnterEvent>
#include <QDropEvent>
#include <QFileDialog>
#include <QFileInfo>
#include <QFormLayout>
#include <QFrame>
#include <QGridLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QListWidget>
#include <QMessageBox>
#include <QMimeData>
#include <QPainter>
#include <QScrollArea>
#include <QShortcut>
#include <QSignalBlocker>
#include <QSlider>
#include <QSpinBox>
#include <QStackedWidget>
#include <QToolButton>
#include <QUrl>
#include <QVBoxLayout>
#include <cmath>
#include <functional>

namespace {

const char *kStyle = R"(
* { font-family: "Segoe UI","Noto Sans Arabic","Noto Sans","Helvetica Neue",Arial,sans-serif; }
QWidget { color:#e6ebf2; font-size:12px; }
QMainWindow, #central { background:#0a0d12; }
#topbar { background:#0d1117; border-bottom:1px solid #1a212b; }
#sidebar { background:#0d1117; border-right:1px solid #1a212b; }
#rightPanel { background:#0d1117; border-left:1px solid #1a212b; }
#card { background:#0e131a; border:1px solid #1c2430; border-radius:14px; }
#footer { background:transparent; border:none; border-top:1px solid #1c2430; }
QLabel { background:transparent; }
#brand { font-size:17px; font-weight:700; color:#f2f5f9; }
#brandSub { font-size:9px; color:#7e8a99; }
#muted { color:#7e8a99; }
#crumb { color:#8f9aa8; }
#crumbActive { color:#f2f5f9; }
#h1 { font-size:19px; font-weight:700; color:#f4f7fb; }
#h2 { font-size:14px; font-weight:700; color:#f4f7fb; }
#range { color:#566170; font-size:11px; }
#spark { color:#b8f45c; font-size:18px; }
#dot { background:#b8f45c; border-radius:4px; }
#badge { background:#1b222c; border-radius:9px; padding:1px 8px; color:#cfd6df; font-size:11px; }
QPushButton#primaryBtn { background:#b8f45c; color:#10170a; border:none; border-radius:10px; padding:9px 16px; font-weight:700; }
QPushButton#primaryBtn:hover { background:#c9ff72; }
QPushButton#primaryBtn:disabled { background:#2a3320; color:#66705a; }
QPushButton#ghostBtn, QToolButton#iconBtn { background:transparent; border:none; color:#cfd6df; padding:9px 12px; border-radius:9px; }
QPushButton#ghostBtn:hover, QToolButton#iconBtn:hover { background:#161d27; }
QToolButton#iconBtn { font-size:18px; }
QToolButton#iconBtn:disabled { color:#3b4552; }
QPushButton#langBtn { border:1px solid #2a3340; border-radius:9px; background:#121821; color:#b8f45c; font-weight:700; padding:7px 13px; }
QPushButton#langBtn:hover { border-color:#b8f45c; }
QPushButton#avatar { background:#1a212b; border:none; border-radius:17px; min-width:34px; max-width:34px; min-height:34px; max-height:34px; font-weight:700; }
QPushButton#avatar:hover { background:#232c39; }
QPushButton#chip { background:transparent; border:none; border-radius:8px; padding:8px 14px; color:#9aa5b3; }
QPushButton#chip:hover { color:#fff; }
QPushButton#chip:checked { background:#1b222c; color:#fff; }
QPushButton#tab { background:transparent; border:none; border-bottom:2px solid transparent; padding:12px 14px; color:#8a95a3; }
QPushButton#tab:hover { color:#fff; }
QPushButton#tab:checked { color:#fff; border-bottom:2px solid #b8f45c; }
QToolButton#sideBtn { background:transparent; border:1px solid transparent; border-radius:12px; color:#8a95a3; font-size:10px; padding:6px 2px; }
QToolButton#sideBtn:hover { color:#fff; }
QToolButton#sideBtn:checked { background:#16201a; border:1px solid #2e4224; color:#b8f45c; }
#searchBox { background:#0a0d12; border:1px solid #1f2733; border-radius:11px; }
#searchBox QLineEdit { border:none; background:transparent; padding:11px 6px; }
#kbd { border:1px solid #2a3340; border-radius:6px; background:#121821; color:#9aa5b3; padding:3px 9px; }
#tipCard { background:#0e131a; border:1px solid #1c2430; border-radius:12px; }
QLineEdit, QSpinBox, QDoubleSpinBox, QComboBox { background:#0a0d12; border:1px solid #232c39; border-radius:8px; padding:7px 10px; selection-background-color:#3b5a1d; }
QLineEdit:focus, QSpinBox:focus, QComboBox:focus { border-color:#b8f45c; }
QComboBox QAbstractItemView { background:#121821; border:1px solid #232c39; selection-background-color:#27371a; }
QSlider::groove:horizontal { height:4px; background:#232c39; border-radius:2px; }
QSlider::sub-page:horizontal { background:#b8f45c; border-radius:2px; }
QSlider::handle:horizontal { background:#b8f45c; width:14px; height:14px; margin:-6px 0; border-radius:7px; }
QDialog, QMessageBox { background:#0d1117; }
QDialog QPushButton, QMessageBox QPushButton { background:#161d27; border:1px solid #2a3340; border-radius:8px; padding:8px 18px; min-width:70px; }
QDialog QPushButton:hover, QMessageBox QPushButton:hover { border-color:#b8f45c; }
QDialog QPushButton:default, QMessageBox QPushButton:default { background:#b8f45c; color:#10170a; border:none; font-weight:700; }
QListWidget { background:transparent; border:none; outline:none; }
QListWidget::item { color:#9aa5b3; border:1px solid #1f2733; border-radius:9px; padding:4px; }
QListWidget::item:hover { border-color:#34404f; }
QListWidget::item:selected { border:1px solid #b8f45c; color:#fff; background:#121821; }
QScrollArea, QScrollArea > QWidget > QWidget { border:none; background:transparent; }
#pendingBar { background:#0e131a; border-top:1px solid #1a212b; }
#tabs { background:transparent; border:none; border-bottom:1px solid #1a212b; }
QScrollBar:vertical { background:transparent; width:8px; margin:2px; }
QScrollBar::handle:vertical { background:#242d3a; border-radius:4px; min-height:30px; }
QScrollBar:horizontal { background:transparent; height:8px; margin:2px; }
QScrollBar::handle:horizontal { background:#242d3a; border-radius:4px; min-width:30px; }
QScrollBar::add-line, QScrollBar::sub-line { width:0; height:0; }
QScrollBar::add-page, QScrollBar::sub-page { background:transparent; }
QToolTip { background:#161d27; color:#e6ebf2; border:1px solid #2a3340; padding:4px; }
)";

struct FDef { int id; const char *glyph; int section; };
const FDef kDefs[] = {
    {1, "◐", 0}, {2, "◒", 0}, {3, "◑", 0}, {4, "▣", 0}, {5, "⇆", 0}, {6, "↻", 0}, {7, "☼", 0}, {8, "⤢", 0},
    {9, "▧", 1}, {10, "⌗", 1}, {11, "▫", 1}, {12, "◌", 1},
    {13, "☀", 2}, {14, "▤", 2}, {15, "✦", 2}, {16, "◉", 2}, {17, "▱", 2}, {18, "▨", 2},
};
const int kMaxHistory = 25;

// Tile used for history entries: dark rounded card with the filter's icon.
QPixmap historyTile(int iconId)
{
    const qreal dpr = 2.0;
    QPixmap pm(int(104 * dpr), int(62 * dpr));
    pm.setDevicePixelRatio(dpr);
    pm.fill(Qt::transparent);
    QPainter p(&pm);
    p.setRenderHint(QPainter::Antialiasing);
    p.setPen(QPen(QColor("#1f2733"), 1));
    p.setBrush(QColor("#10161e"));
    p.drawRoundedRect(QRectF(0.5, 0.5, 103, 61), 8, 8);
    Icons::draw(p, iconId, QRectF(52 - 14, 31 - 14, 28, 28), QColor("#b8f45c"));
    return pm;
}

QPixmap makeLogo(int size)
{
    const qreal dpr = qApp->devicePixelRatio();
    QPixmap pm(int(size * dpr), int(size * dpr));
    pm.setDevicePixelRatio(dpr);
    pm.fill(Qt::transparent);
    QPainter p(&pm);
    p.setRenderHint(QPainter::Antialiasing);
    p.setPen(Qt::NoPen);
    const double s = size * 0.46, g = size * 0.08;
    const QColor cols[4] = {QColor("#b8f45c"), QColor("#7fd04a"), QColor("#6bc13f"), QColor("#a2e552")};
    for (int i = 0; i < 4; ++i) {
        p.setBrush(cols[i]);
        p.drawRoundedRect(QRectF((i % 2) * (s + g), (i / 2) * (s + g), s, s), size * 0.12, size * 0.12);
    }
    return pm;
}

QLabel *mk(const QString &obj, QWidget *parent = nullptr)
{
    auto *l = new QLabel(parent);
    if (!obj.isEmpty()) l->setObjectName(obj);
    return l;
}

} // namespace

// ============================================================================
//  FilterTile
// ============================================================================
FilterTile::FilterTile(int id, const QString &glyph, QWidget *parent)
    : QPushButton(parent), id_(id), glyph_(glyph)
{
    setCursor(Qt::PointingHandCursor);
    setMinimumHeight(72);
    setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
    setFocusPolicy(Qt::TabFocus);
    setCheckable(true);
}

void FilterTile::paintEvent(QPaintEvent *)
{
    QPainter p(this);
    p.setRenderHint(QPainter::Antialiasing);
    p.setRenderHint(QPainter::TextAntialiasing);
    const bool hot = underMouse() || hasFocus() || isChecked();
    QRectF r = QRectF(rect()).adjusted(0.5, 0.5, -0.5, -0.5);
    p.setPen(QPen(hot ? QColor("#b8f45c") : QColor("#1f2733"), 1));
    p.setBrush(isDown() ? QColor("#1a2230") : (hot ? QColor("#141b25") : QColor("#10161e")));
    p.drawRoundedRect(r, 9, 9);

    QFont f = font();
    f.setPixelSize(8);
    p.setFont(f);
    p.setPen(QColor("#566170"));
    p.drawText(QRectF(8, 5, width() - 16, 12), Qt::AlignLeft | Qt::AlignVCenter, num_);

    Icons::draw(p, id_, QRectF((width() - 26) / 2.0, 15, 26, 26), hot ? QColor("#b8f45c") : QColor("#dfe5ec"));

    f.setPixelSize(10);
    while (f.pixelSize() > 7 && QFontMetrics(f).horizontalAdvance(label_) > width() - 8) f.setPixelSize(f.pixelSize() - 1);
    p.setFont(f);
    p.setPen(QColor("#aeb8c5"));
    p.drawText(QRectF(4, height() - 24, width() - 8, 18), Qt::AlignCenter, label_);
}

// ============================================================================
//  Strings (English / Arabic)
// ============================================================================
void MainWindow::initStrings()
{
#define S(k, en, ar) strings_.insert(QStringLiteral(k), qMakePair(QString::fromUtf8(en), QString::fromUtf8(ar)));
    S("studio", "Wow Studio", "مشهد واو")
    S("untitled", "Untitled project", "مشروع بدون عنوان")
    S("open", "Open image", "فتح صورة")
    S("save", "Save image", "حفظ الصورة")
    S("undo", "Undo (Ctrl+Z)", "تراجع (Ctrl+Z)")
    S("redo", "Redo (Ctrl+Y)", "إعادة (Ctrl+Y)")
    S("side.edit", "Edit", "تحرير")
    S("side.filters", "Filters", "الفلاتر")
    S("side.history", "History", "السجل")
    S("side.help", "Help", "مساعدة")
    S("side.local", "Local", "محلي")
    S("compare", "Compare", "مقارنة")
    S("fit", "Fit", "ملاءمة")
    S("workspace", "Workspace", "مساحة العمل")
    S("editor", "Image editor", "محرر الصور")
    S("tab.filters", "Filters", "الفلاتر")
    S("tab.adjust", "Adjust image", "ضبط الصورة")
    S("filters.title", "Filters", "الفلاتر")
    S("filters.sub", "Pick an effect and tweak its settings", "اختر التأثير وعدل إعداداته")
    S("search", "Search for a filter…", "ابحث عن فلتر…")
    S("sec0", "Basics", "الأساسيات")
    S("sec1", "Composition & details", "التركيب والتفاصيل")
    S("sec2", "Wow touch", "لمسة واو")
    S("f1", "Greyscale", "تدرج رمادي")
    S("f2", "Black & White", "أبيض وأسود")
    S("f3", "Invert", "عكس الألوان")
    S("f4", "Frame", "إطار")
    S("f5", "Flip", "انعكاس")
    S("f6", "Rotate", "تدوير")
    S("f7", "Brightness", "السطوع")
    S("f8", "Resize", "تغيير الحجم")
    S("f9", "Merge", "دمج")
    S("f10", "Edges", "الحواف")
    S("f11", "Crop", "اقتصاص")
    S("f12", "Blur", "ضبابية")
    S("f13", "Sunlight", "ضوء واو")
    S("f14", "Old TV", "تلفاز قديم")
    S("f15", "Purple Night", "ليلة أرجوانية")
    S("f16", "Infrared", "أشعة تحت الحمراء")
    S("f17", "Skew", "إمالة")
    S("f18", "Oil Painting", "رسم زيتي")
    S("history.title", "Edit history", "سجل التعديلات")
    S("history.clear", "Clear history", "مسح السجل")
    S("history.hint", "Pick a filter to add it to the history", "اختر فلتراً لإضافته إلى سجل التعديلات")
    S("original", "Original", "الأصل")
    S("current", "Current", "الحالية")
    S("pending", "Preview: ", "معاينة: ")
    S("t.undone", "Undone: ", "تم التراجع عن: ")
    S("adjust", "Adjustment", "ضبط")
    S("edited", "Edited", "المعدّلة")
    S("preview", "Live preview", "معاينة مباشرة")
    S("tip", "Tip: press / to search filters", "نصيحة: اضغط / للبحث عن فلتر")
    S("adj.sub", "Fine-tune brightness and contrast", "اضبط السطوع والتباين بدقة")
    S("adj.brightness", "Brightness", "السطوع")
    S("adj.contrast", "Contrast", "التباين")
    S("adj.apply", "Apply", "تطبيق")
    S("adj.reset", "Reset", "إعادة ضبط")
    S("empty", "Open an image or drop it here", "افتح صورة أو أفلتها هنا")
    S("t.noimage", "Open an image first", "افتح صورة أولاً")
    S("t.saved", "Image saved", "تم حفظ الصورة")
    S("t.savefail", "Could not save the image", "تعذر حفظ الصورة")
    S("t.loadfail", "Could not open the image", "تعذر فتح الصورة")
    S("t.applied", "Applied: ", "تم تطبيق: ")
    S("p.type", "Type", "النوع")
    S("p.simple", "Simple", "بسيط")
    S("p.fancy", "Fancy", "مزخرف")
    S("p.thickness", "Thickness", "السماكة")
    S("p.color", "Color", "اللون")
    S("p.direction", "Direction", "الاتجاه")
    S("p.horizontal", "Horizontal", "أفقي")
    S("p.vertical", "Vertical", "رأسي")
    S("p.angle", "Angle", "الزاوية")
    S("p.mode", "Mode", "الوضع")
    S("p.darken", "Darken", "تغميق")
    S("p.lighten", "Lighten", "تفتيح")
    S("p.level", "Level", "المستوى")
    S("p.width", "Width", "العرض")
    S("p.height", "Height", "الارتفاع")
    S("p.ratio", "Keep aspect ratio", "الحفاظ على النسبة")
    S("p.second", "Second image", "الصورة الثانية")
    S("p.browse", "Browse…", "استعراض…")
    S("p.biggest", "Use the biggest size", "استخدام أكبر مقاس")
    S("p.smallest", "Use the smallest size", "استخدام أصغر مقاس")
    S("p.strength", "Strength (passes)", "القوة (عدد المرات)")
    S("p.radius", "Radius", "نصف القطر")
    S("p.levels", "Intensity levels", "مستويات الشدة")
    S("p.x", "Start X", "البداية X")
    S("p.y", "Start Y", "البداية Y")
    S("ok", "OK", "موافق")
    S("cancel", "Cancel", "إلغاء")
    S("help.title", "Phascinate - Help", "فاسينيت - مساعدة")
    S("help.body",
      "Ctrl+O  Open image\nCtrl+S  Save image\nCtrl+Z / Ctrl+Y  Undo / Redo\n/  Search filters\n\nMouse wheel: zoom   -   Drag: pan   -   Double-click: fit\n"
      "Compare: drag the green handle to see before / after.\n\nYou can also drop an image file on the window.",
      "Ctrl+O  فتح صورة\nCtrl+S  حفظ الصورة\nCtrl+Z / Ctrl+Y  تراجع / إعادة\n/  البحث عن فلتر\n\nعجلة الماوس: تكبير   -   السحب: تحريك   -   نقر مزدوج: ملاءمة\n"
      "المقارنة: اسحب المقبض الأخضر لرؤية قبل / بعد.\n\nيمكنك أيضاً إفلات ملف صورة على النافذة.")
#undef S
}

QString MainWindow::T(const QString &key) const
{
    auto it = strings_.constFind(key);
    if (it == strings_.constEnd()) return key;
    return ar_ ? it->second : it->first;
}

// ============================================================================
//  Construction
// ============================================================================
MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent)
{
    setWindowTitle(QStringLiteral("Phascinate"));
    resize(1500, 920);
    setMinimumSize(1120, 720);
    setAcceptDrops(true);
    qApp->setStyleSheet(QString::fromUtf8(kStyle));

    initStrings();
    buildUi();
    retranslate();
    updateButtons();
    updateInfo();
}

void MainWindow::buildUi()
{
    auto *central = new QWidget;
    central->setObjectName("central");
    setCentralWidget(central);
    auto *root = new QVBoxLayout(central);
    root->setContentsMargins(0, 0, 0, 0);
    root->setSpacing(0);
    root->addWidget(buildTopBar());

    auto *body = new QHBoxLayout;
    body->setContentsMargins(0, 0, 0, 0);
    body->setSpacing(0);
    body->addWidget(buildSidebar());
    body->addWidget(buildCenter(), 1);
    body->addWidget(buildRightPanel());
    root->addLayout(body, 1);

    auto sc = [this](const QKeySequence &k, auto fn) {
        auto *s = new QShortcut(k, this);
        connect(s, &QShortcut::activated, this, fn);
    };
    sc(QKeySequence::Open, [this] { openDialog(); });
    sc(QKeySequence::Save, [this] { saveDialog(); });
    sc(QKeySequence::Undo, [this] { undo(); });
    sc(QKeySequence(Qt::CTRL | Qt::Key_Y), [this] { redo(); });
    sc(QKeySequence(Qt::CTRL | Qt::SHIFT | Qt::Key_Z), [this] { redo(); });
    sc(QKeySequence(Qt::Key_Slash), [this] {
        stack_->setCurrentIndex(0);
        filtersTab_->setChecked(true);
        sideFilters_->setChecked(true);
        search_->setFocus();
        search_->selectAll();
    });
}

QWidget *MainWindow::buildTopBar()
{
    auto *bar = new QFrame;
    bar->setObjectName("topbar");
    bar->setFixedHeight(68);
    auto *h = new QHBoxLayout(bar);
    h->setContentsMargins(20, 0, 24, 0);
    h->setSpacing(10);

    auto *logo = new QLabel;
    logo->setPixmap(makeLogo(34));
    h->addWidget(logo);

    auto *names = new QVBoxLayout;
    names->setSpacing(0);
    auto *name = mk("brand");
    name->setText(QStringLiteral("Phascinate"));
    auto *sub = mk("brandSub");
    sub->setText(QStringLiteral("IMAGE WORKSHOP"));
    QFont sf = sub->font();
    sf.setLetterSpacing(QFont::AbsoluteSpacing, 3);
    sub->setFont(sf);
    names->addStretch();
    names->addWidget(name);
    names->addWidget(sub);
    names->addStretch();
    h->addLayout(names);
    h->addSpacing(110);

    h->addStretch();

    langBtn_ = new QPushButton;
    langBtn_->setObjectName("langBtn");
    langBtn_->setCursor(Qt::PointingHandCursor);
    connect(langBtn_, &QPushButton::clicked, this, [this] { ar_ = !ar_; retranslate(); });
    h->addWidget(langBtn_);

    undoBtn_ = new QToolButton;
    undoBtn_->setObjectName("iconBtn");
    undoBtn_->setText(QStringLiteral("↶"));
    redoBtn_ = new QToolButton;
    redoBtn_->setObjectName("iconBtn");
    redoBtn_->setText(QStringLiteral("↷"));
    connect(undoBtn_, &QToolButton::clicked, this, &MainWindow::undo);
    connect(redoBtn_, &QToolButton::clicked, this, &MainWindow::redo);
    h->addWidget(undoBtn_);
    h->addWidget(redoBtn_);

    auto *vs = new QFrame;
    vs->setFixedSize(1, 26);
    vs->setStyleSheet("background:#222b37;");
    h->addSpacing(6);
    h->addWidget(vs);
    h->addSpacing(6);

    openBtn_ = new QPushButton;
    openBtn_->setObjectName("ghostBtn");
    openBtn_->setCursor(Qt::PointingHandCursor);
    connect(openBtn_, &QPushButton::clicked, this, &MainWindow::openDialog);
    h->addWidget(openBtn_);

    saveBtn_ = new QPushButton;
    saveBtn_->setObjectName("primaryBtn");
    saveBtn_->setCursor(Qt::PointingHandCursor);
    connect(saveBtn_, &QPushButton::clicked, this, &MainWindow::saveDialog);
    h->addWidget(saveBtn_);

    auto *av = new QPushButton(QStringLiteral("P"));
    av->setObjectName("avatar");
    av->setCursor(Qt::PointingHandCursor);
    connect(av, &QPushButton::clicked, this, [this] {
        QMessageBox::about(this, "Phascinate",
                           "<b>Phascinate</b> - Image Workshop<br>18 filters · Qt C++<br><br>Mahmoud Waleed · Ahmed Ismail · Ahmed Walid · Mohammed Mokhtar");
    });
    h->addWidget(av);
    return bar;
}

QWidget *MainWindow::buildSidebar()
{
    auto *bar = new QFrame;
    bar->setObjectName("sidebar");
    bar->setFixedWidth(68);
    auto *v = new QVBoxLayout(bar);
    v->setContentsMargins(8, 16, 8, 14);
    v->setSpacing(8);

    auto mkBtn = [&](int iconId, bool checkable) {
        auto *b = new QToolButton;
        b->setObjectName("sideBtn");
        b->setCheckable(checkable);
        b->setAutoExclusive(checkable);
        b->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);
        b->setIcon(Icons::icon(iconId, 22, QColor("#8a95a3"), QColor("#b8f45c")));
        b->setIconSize(QSize(22, 22));
        b->setFixedSize(56, 58);
        b->setCursor(Qt::PointingHandCursor);
        v->addWidget(b, 0, Qt::AlignHCenter);
        return b;
    };
    sideFilters_ = mkBtn(101, true);
    sideFilters_->setChecked(true);
    v->addStretch();
    sideHelp_ = mkBtn(102, false);
    sideLocal_ = mk("muted");
    sideLocal_->setAlignment(Qt::AlignCenter);
    v->addWidget(sideLocal_);

    connect(sideFilters_, &QToolButton::clicked, this, [this] { stack_->setCurrentIndex(0); filtersTab_->setChecked(true); });
    connect(sideHelp_, &QToolButton::clicked, this, [this] {
        QMessageBox::information(this, T("help.title"), T("help.body"));
    });
    return bar;
}

QWidget *MainWindow::buildCenter()
{
    auto *w = new QWidget;
    auto *v = new QVBoxLayout(w);
    v->setContentsMargins(20, 12, 20, 14);
    v->setSpacing(12);

    // ---- toolbar ----
    auto *tb = new QHBoxLayout;
    tb->setSpacing(4);
    compareBtn_ = new QPushButton;
    compareBtn_->setObjectName("chip");
    compareBtn_->setCheckable(true);
    zoom100Btn_ = new QPushButton(QStringLiteral("100%"));
    zoom100Btn_->setObjectName("chip");
    fitBtn_ = new QPushButton;
    fitBtn_->setObjectName("chip");
    for (auto *b : {compareBtn_, zoom100Btn_, fitBtn_}) b->setCursor(Qt::PointingHandCursor);
    auto *sep = new QFrame;
    sep->setFixedSize(1, 18);
    sep->setStyleSheet("background:#222b37;");
    tb->addWidget(compareBtn_);
    tb->addSpacing(6);
    tb->addWidget(sep);
    tb->addSpacing(6);
    tb->addWidget(zoom100Btn_);
    tb->addWidget(fitBtn_);
    tb->addStretch();
    wsLbl_ = mk("crumb");
    auto *chev = mk("crumb");
    chev->setText(QStringLiteral("‹"));
    edLbl_ = mk("crumbActive");
    tb->addWidget(edLbl_);
    tb->addWidget(chev);
    tb->addWidget(wsLbl_);
    v->addLayout(tb);

    // ---- canvas card ----
    auto *card = new QFrame;
    card->setObjectName("card");
    auto *cv = new QVBoxLayout(card);
    cv->setContentsMargins(0, 0, 0, 0);
    cv->setSpacing(0);
    canvas_ = new ImageCanvas;
    cv->addWidget(canvas_, 1);

    auto *footer = new QFrame;
    footer->setObjectName("footer");
    footer->setFixedHeight(40);
    auto *fh = new QHBoxLayout(footer);
    fh->setContentsMargins(18, 0, 18, 0);
    fh->setSpacing(10);
    auto *zin = new QToolButton;
    zin->setObjectName("iconBtn");
    zin->setText("+");
    auto *zout = new QToolButton;
    zout->setObjectName("iconBtn");
    zout->setText(QStringLiteral("−"));
    zoomLbl_ = new QLabel("100%");
    zoomLbl_->setMinimumWidth(40);
    zoomSlider_ = new QSlider(Qt::Horizontal);
    zoomSlider_->setRange(5, 400);
    zoomSlider_->setFixedWidth(120);
    infoLbl_ = mk("muted");
    fh->addWidget(zin);
    fh->addWidget(zoomLbl_);
    fh->addWidget(zoomSlider_);
    fh->addWidget(zout);
    fh->addStretch();
    fh->addWidget(infoLbl_);
    cv->addWidget(footer);
    v->addWidget(card, 1);

    // ---- history ----
    histFrame_ = new QFrame;
    histFrame_->setObjectName("card");
    histFrame_->setFixedHeight(172);
    auto *hv = new QVBoxLayout(histFrame_);
    hv->setContentsMargins(18, 12, 18, 12);
    hv->setSpacing(6);
    auto *hh = new QHBoxLayout;
    histTitle_ = mk("h2");
    histBadge_ = mk("badge");
    histClear_ = new QPushButton;
    histClear_->setObjectName("ghostBtn");
    histClear_->setCursor(Qt::PointingHandCursor);
    hh->addWidget(histTitle_);
    hh->addWidget(histBadge_);
    hh->addStretch();
    hh->addWidget(histClear_);
    hv->addLayout(hh);

    auto *hr = new QHBoxLayout;
    histList_ = new QListWidget;
    histList_->setViewMode(QListView::IconMode);
    histList_->setFlow(QListView::LeftToRight);
    histList_->setWrapping(false);
    histList_->setMovement(QListView::Static);
    histList_->setIconSize(QSize(104, 62));
    histList_->setSpacing(6);
    histList_->setHorizontalScrollMode(QAbstractItemView::ScrollPerPixel);
    histList_->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    hr->addWidget(histList_, 3);
    histHint_ = mk("muted");
    histHint_->setWordWrap(true);
    hr->addWidget(histHint_, 2);
    hv->addLayout(hr, 1);
    v->addWidget(histFrame_);

    // ---- connections ----
    connect(compareBtn_, &QPushButton::toggled, this, [this](bool on) {
        if (!canvas_->hasImage()) { compareBtn_->setChecked(false); canvas_->showToast(T("t.noimage")); return; }
        canvas_->setCompare(on);
    });
    connect(zoom100Btn_, &QPushButton::clicked, this, [this] { canvas_->setZoom(1.0); });
    connect(fitBtn_, &QPushButton::clicked, canvas_, &ImageCanvas::fit);
    connect(zoomSlider_, &QSlider::valueChanged, this, [this](int v) { canvas_->setZoom(v / 100.0); });
    connect(zin, &QToolButton::clicked, this, [this] { canvas_->setZoom(canvas_->zoom() * 1.15); });
    connect(zout, &QToolButton::clicked, this, [this] { canvas_->setZoom(canvas_->zoom() / 1.15); });
    connect(canvas_, &ImageCanvas::zoomChanged, this, [this](double z) {
        QSignalBlocker b(zoomSlider_);
        zoomSlider_->setValue(int(std::lround(z * 100)));
        zoomLbl_->setText(QString::number(int(std::lround(z * 100))) + "%");
        fitBtn_->setCheckable(true);
        fitBtn_->setChecked(canvas_->isFit());
        zoom100Btn_->setCheckable(true);
        zoom100Btn_->setChecked(!canvas_->isFit() && std::abs(z - 1.0) < 0.005);
    });
    connect(canvas_, &ImageCanvas::clicked, this, &MainWindow::openDialog);
    connect(histClear_, &QPushButton::clicked, this, &MainWindow::clearHistory);
    connect(histList_, &QListWidget::itemClicked, this, [this](QListWidgetItem *it) {
        gotoHistory(it->data(Qt::UserRole).toInt());
    });
    return w;
}

QWidget *MainWindow::buildRightPanel()
{
    rightPanel_ = new QFrame;
    rightPanel_->setObjectName("rightPanel");
    rightPanel_->setFixedWidth(372);
    auto *v = new QVBoxLayout(rightPanel_);
    v->setContentsMargins(0, 0, 0, 0);
    v->setSpacing(0);

    auto *tabs = new QFrame;
    tabs->setObjectName("tabs");
    auto *th = new QHBoxLayout(tabs);
    th->setContentsMargins(20, 0, 20, 0);
    th->setSpacing(4);
    filtersTab_ = new QPushButton;
    adjustTab_ = new QPushButton;
    for (auto *b : {filtersTab_, adjustTab_}) {
        b->setObjectName("tab");
        b->setCheckable(true);
        b->setAutoExclusive(true);
        b->setCursor(Qt::PointingHandCursor);
        th->addWidget(b);
    }
    filtersTab_->setChecked(true);
    th->addStretch();
    v->addWidget(tabs);

    stack_ = new QStackedWidget;
    stack_->addWidget(buildFiltersPage());
    stack_->addWidget(buildAdjustPage());
    v->addWidget(stack_, 1);

    pendingBar_ = new QFrame;
    pendingBar_->setObjectName("pendingBar");
    auto *pb = new QHBoxLayout(pendingBar_);
    pb->setContentsMargins(22, 14, 22, 14);
    pb->setSpacing(10);
    pendingLbl_ = new QLabel;
    pendCancel_ = new QPushButton;
    pendCancel_->setObjectName("ghostBtn");
    pendApply_ = new QPushButton;
    pendApply_->setObjectName("primaryBtn");
    for (auto *b : {pendCancel_, pendApply_}) b->setCursor(Qt::PointingHandCursor);
    pb->addWidget(pendingLbl_, 1);
    pb->addWidget(pendCancel_);
    pb->addWidget(pendApply_);
    pendingBar_->hide();
    v->addWidget(pendingBar_);
    connect(pendApply_, &QPushButton::clicked, this, &MainWindow::applyPending);
    connect(pendCancel_, &QPushButton::clicked, this, [this] { cancelPending(); });

    connect(filtersTab_, &QPushButton::clicked, this, [this] { stack_->setCurrentIndex(0); sideFilters_->setChecked(true); });
    connect(adjustTab_, &QPushButton::clicked, this, [this] { stack_->setCurrentIndex(1); });
    return rightPanel_;
}

QWidget *MainWindow::buildFiltersPage()
{
    auto *scroll = new QScrollArea;
    scroll->setWidgetResizable(true);
    scroll->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    auto *page = new QWidget;
    scroll->setWidget(page);
    auto *v = new QVBoxLayout(page);
    v->setContentsMargins(18, 18, 18, 18);
    v->setSpacing(11);

    // header
    auto *hh = new QHBoxLayout;
    auto *tb = new QVBoxLayout;
    tb->setSpacing(2);
    fTitle_ = mk("h1");
    fSub_ = mk("muted");
    fSub_->setStyleSheet("font-size:11px;");
    tb->addWidget(fTitle_);
    tb->addWidget(fSub_);
    auto *spark = mk("spark");
    spark->setText(QStringLiteral("✦"));
    spark->setAlignment(Qt::AlignTop);
    hh->addLayout(tb);
    hh->addStretch();
    hh->addWidget(spark);
    v->addLayout(hh);

    // search
    auto *box = new QFrame;
    box->setObjectName("searchBox");
    auto *sh = new QHBoxLayout(box);
    sh->setContentsMargins(12, 2, 10, 2);
    auto *mag = mk("muted");
    mag->setText(QStringLiteral("⌕"));
    mag->setStyleSheet("font-size:16px;");
    search_ = new QLineEdit;
    search_->setClearButtonEnabled(true);
    auto *kbd = mk("kbd");
    kbd->setText("/");
    sh->addWidget(mag);
    sh->addWidget(search_, 1);
    sh->addWidget(kbd);
    v->addWidget(box);
    connect(search_, &QLineEdit::textChanged, this, [this](const QString &t) { query_ = t.trimmed().toLower(); layoutFilters(); });

    // sections
    for (int s = 0; s < 3; ++s) {
        sec_[s].box = new QWidget;
        auto *sv = new QVBoxLayout(sec_[s].box);
        sv->setContentsMargins(0, 8, 0, 0);
        sv->setSpacing(10);
        auto *row = new QHBoxLayout;
        sec_[s].title = mk("h2");
        sec_[s].range = mk("range");
        row->addWidget(sec_[s].title);
        row->addStretch();
        row->addWidget(sec_[s].range);
        sv->addLayout(row);
        sec_[s].grid = new QGridLayout;
        sec_[s].grid->setSpacing(8);
        for (int c = 0; c < 4; ++c) sec_[s].grid->setColumnStretch(c, 1);
        sv->addLayout(sec_[s].grid);
        v->addWidget(sec_[s].box);
    }
    static const char *ranges[3] = {"01 — 08", "09 — 12", "13 — 18"};
    for (int s = 0; s < 3; ++s) sec_[s].range->setText(QString::fromUtf8(ranges[s]));

    for (const FDef &d : kDefs) {
        auto *t = new FilterTile(d.id, QString::fromUtf8(d.glyph));
        connect(t, &QPushButton::clicked, this, [this, id = d.id] { selectFilter(id); });
        tiles_.push_back(t);
    }

    auto *tip = new QFrame;
    tip->setObjectName("tipCard");
    auto *tl = new QHBoxLayout(tip);
    tl->setContentsMargins(16, 14, 16, 14);
    tipLbl_ = mk("muted");
    tipLbl_->setStyleSheet("font-size:11px;");
    tl->addWidget(tipLbl_);
    v->addSpacing(6);
    v->addWidget(tip);
    v->addStretch();
    return scroll;
}

QWidget *MainWindow::buildAdjustPage()
{
    auto *page = new QWidget;
    auto *v = new QVBoxLayout(page);
    v->setContentsMargins(18, 18, 18, 18);
    v->setSpacing(14);
    aTitle_ = mk("h1");
    aSub_ = mk("muted");
    aSub_->setStyleSheet("font-size:11px;");
    v->addWidget(aTitle_);
    v->addWidget(aSub_);
    v->addSpacing(10);

    auto addRow = [&](QLabel *&name, QLabel *&val, QSlider *&sl) {
        auto *r = new QHBoxLayout;
        name = new QLabel;
        val = mk("badge");
        val->setText("0");
        r->addWidget(name);
        r->addStretch();
        r->addWidget(val);
        v->addLayout(r);
        sl = new QSlider(Qt::Horizontal);
        sl->setRange(-100, 100);
        sl->setValue(0);
        v->addWidget(sl);
        v->addSpacing(8);
    };
    addRow(aBright_, bVal_, brightSlider_);
    addRow(aContrast_, cVal_, contrastSlider_);

    auto *br = new QHBoxLayout;
    adjReset_ = new QPushButton;
    adjApply_ = new QPushButton;
    adjApply_->setObjectName("primaryBtn");
    adjReset_->setObjectName("ghostBtn");
    br->addWidget(adjReset_);
    br->addStretch();
    br->addWidget(adjApply_);
    v->addLayout(br);
    v->addStretch();

    connect(brightSlider_, &QSlider::valueChanged, this, &MainWindow::onAdjustChanged);
    connect(contrastSlider_, &QSlider::valueChanged, this, &MainWindow::onAdjustChanged);
    connect(adjApply_, &QPushButton::clicked, this, &MainWindow::applyAdjust);
    connect(adjReset_, &QPushButton::clicked, this, [this] {
        brightSlider_->setValue(0);
        contrastSlider_->setValue(0);
    });
    return page;
}

// ============================================================================
//  Language
// ============================================================================
void MainWindow::retranslate()
{
    const Qt::LayoutDirection dir = ar_ ? Qt::RightToLeft : Qt::LeftToRight;
    rightPanel_->setLayoutDirection(dir);
    histFrame_->setLayoutDirection(dir);

    langBtn_->setText(ar_ ? QString::fromUtf8("ع") : QStringLiteral("Eng"));
    openBtn_->setText(QStringLiteral("＋  ") + T("open"));
    saveBtn_->setText(T("save") + QStringLiteral("  ⤓"));
    undoBtn_->setToolTip(T("undo"));
    redoBtn_->setToolTip(T("redo"));

    sideFilters_->setText(T("side.filters"));
    sideHelp_->setText(T("side.help"));
    sideLocal_->setText(QStringLiteral("● ") + T("side.local"));

    compareBtn_->setText(QStringLiteral("◐  ") + T("compare"));
    fitBtn_->setText(T("fit"));
    wsLbl_->setText(T("workspace"));
    edLbl_->setText(T("editor"));

    filtersTab_->setText(T("tab.filters") + "  ·  18");
    adjustTab_->setText(T("tab.adjust"));
    fTitle_->setText(T("filters.title"));
    fSub_->setText(T("filters.sub"));
    search_->setPlaceholderText(T("search"));
    for (int s = 0; s < 3; ++s) sec_[s].title->setText(T(QString("sec%1").arg(s)));
    for (size_t i = 0; i < tiles_.size(); ++i)
        tiles_[i]->setNumberAndLabel(QString("%1").arg(i + 1, 2, 10, QChar('0')), T(QString("f%1").arg(i + 1)));
    tipLbl_->setText(T("tip"));
    pendApply_->setText(T("adj.apply"));
    pendCancel_->setText(T("cancel"));
    if (pendingId_) pendingLbl_->setText(T("pending") + T(QString("f%1").arg(pendingId_)));

    aTitle_->setText(T("tab.adjust"));
    aSub_->setText(T("adj.sub"));
    aBright_->setText(T("adj.brightness"));
    aContrast_->setText(T("adj.contrast"));
    adjApply_->setText(T("adj.apply"));
    adjReset_->setText(T("adj.reset"));

    histTitle_->setText(T("history.title"));
    histClear_->setText(T("history.clear"));
    histHint_->setText(QStringLiteral("＋  ") + T("history.hint"));

    canvas_->setTexts(T("empty"), T("preview"), T("original"), T("edited"));
    layoutFilters();
    refreshHistory();
}

void MainWindow::layoutFilters()
{
    for (auto &s : sec_)
        while (s.grid->count()) delete s.grid->takeAt(0);

    int counts[3] = {0, 0, 0};
    for (size_t i = 0; i < tiles_.size(); ++i) {
        const FDef &d = kDefs[i];
        const QString key = QString("f%1").arg(d.id);
        const auto names = strings_.value(key);
        const bool match = query_.isEmpty() || names.first.toLower().contains(query_) ||
                           names.second.contains(query_) || QString("%1").arg(d.id, 2, 10, QChar('0')).contains(query_);
        if (!match) { tiles_[i]->hide(); continue; }
        int n = counts[d.section]++;
        sec_[d.section].grid->addWidget(tiles_[i], n / 4, n % 4);
        tiles_[i]->show();
    }
    for (int s = 0; s < 3; ++s) sec_[s].box->setVisible(counts[s] > 0);
}

// ============================================================================
//  Image I/O
// ============================================================================
void MainWindow::openDialog()
{
    QString path = QFileDialog::getOpenFileName(this, T("open"), QString(),
                                                "Images (*.png *.jpg *.jpeg *.bmp *.tga *.gif);;All files (*)");
    if (!path.isEmpty()) loadFile(path);
}

bool MainWindow::loadFile(const QString &path)
{
    QImage img(path);
    if (img.isNull()) { canvas_->showToast(T("t.loadfail")); return false; }
    if (img.hasAlphaChannel()) {            // flatten transparency on white (original code forced RGB too)
        QImage flat(img.size(), QImage::Format_RGB888);
        flat.fill(Qt::white);
        QPainter p(&flat);
        p.drawImage(0, 0, img);
        img = flat;
    } else {
        img = img.convertToFormat(QImage::Format_RGB888);
    }
    original_ = img;
    fileName_ = path;
    format_ = QFileInfo(path).suffix().toUpper();
    history_.clear();
    redo_.clear();
    histIdx_ = -1;
    canvas_->setOriginal(original_);
    canvas_->setFileName(QFileInfo(path).fileName());
    compareBtn_->setChecked(false);
    pushHistory("original", img);
    canvas_->fit();
    return true;
}

void MainWindow::saveDialog()
{
    if (histIdx_ < 0) { canvas_->showToast(T("t.noimage")); return; }
    QString def = QFileInfo(fileName_).completeBaseName() + "_phascinate.png";
    QString sel;
    QString path = QFileDialog::getSaveFileName(this, T("save"), def,
                                                "PNG (*.png);;JPEG (*.jpg *.jpeg);;BMP (*.bmp)", &sel);
    if (path.isEmpty()) return;
    if (QFileInfo(path).suffix().isEmpty())
        path += sel.startsWith("JPEG") ? ".jpg" : (sel.startsWith("BMP") ? ".bmp" : ".png");
    if (history_[histIdx_].img.save(path, nullptr, 95)) {
        canvas_->showToast(T("t.saved"));
    } else {
        canvas_->showToast(T("t.savefail"));
    }
}

void MainWindow::dragEnterEvent(QDragEnterEvent *e)
{
    if (e->mimeData()->hasUrls()) e->acceptProposedAction();
}

void MainWindow::dropEvent(QDropEvent *e)
{
    const auto urls = e->mimeData()->urls();
    if (!urls.isEmpty()) loadFile(urls.first().toLocalFile());
}

// ============================================================================
//  History
// ============================================================================
void MainWindow::pushHistory(const QString &key, const QImage &img)
{
    redo_.clear();
    Entry e{key, img, key == "original" ? QPixmap::fromImage(img.scaled(208, 124, Qt::KeepAspectRatio, Qt::FastTransformation)) : QPixmap()};
    history_.push_back(std::move(e));
    if (static_cast<int>(history_.size()) > kMaxHistory) history_.erase(history_.begin() + 1);
    histIdx_ = static_cast<int>(history_.size()) - 1;
    showCurrent();
}

// Pops every entry after `idx` (they go to the redo stack).
void MainWindow::gotoHistory(int idx)
{
    if (idx < 0 || idx >= static_cast<int>(history_.size()) - 1) return;
    while (static_cast<int>(history_.size()) - 1 > idx) {
        redo_.push_back(std::move(history_.back()));
        history_.pop_back();
    }
    histIdx_ = idx;
    showCurrent();
}

void MainWindow::showCurrent()
{
    if (histIdx_ < 0) return;
    cancelPending(false);
    {
        QSignalBlocker b1(brightSlider_), b2(contrastSlider_);
        brightSlider_->setValue(0);
        contrastSlider_->setValue(0);
        bVal_->setText("0");
        cVal_->setText("0");
    }
    canvas_->setEdited(history_[histIdx_].img);
    refreshHistory();
    updateButtons();
    updateInfo();
}

static QString entryName(const QString &key, const std::function<QString(const QString &)> &T)
{
    if (key == "original") return T("original");
    if (key == "adjust") return T("adjust");
    return T(key);
}

void MainWindow::refreshHistory()
{
    QSignalBlocker b(histList_);
    histList_->clear();
    for (size_t i = 0; i < history_.size(); ++i) {
        const Entry &e = history_[i];
        QIcon icon;
        if (i == 0) icon = QIcon(e.thumb);
        else icon = QIcon(historyTile(e.key == "adjust" ? 0 : e.key.mid(1).toInt()));
        auto *it = new QListWidgetItem(icon, entryName(e.key, [this](const QString &k) { return T(k); }));
        it->setData(Qt::UserRole, static_cast<int>(i));
        it->setTextAlignment(Qt::AlignHCenter);
        it->setSizeHint(QSize(116, 100));
        histList_->addItem(it);
    }
    if (histIdx_ >= 0) histList_->setCurrentRow(histIdx_);
    const int edits = std::max(0, static_cast<int>(history_.size()) - 1);
    histBadge_->setText(QString::number(edits));
    histHint_->setVisible(edits == 0);
}

// Back to the original image only.
void MainWindow::clearHistory()
{
    if (histIdx_ < 0 || history_.size() <= 1) return;
    Entry orig = std::move(history_.front());
    history_.clear();
    history_.push_back(std::move(orig));
    redo_.clear();
    histIdx_ = 0;
    showCurrent();
}

// Undo pops the last applied filter off the history.
void MainWindow::undo()
{
    if (history_.size() <= 1) return;
    const QString key = history_.back().key;
    redo_.push_back(std::move(history_.back()));
    history_.pop_back();
    histIdx_ = static_cast<int>(history_.size()) - 1;
    showCurrent();
    canvas_->showToast(T("t.undone") + entryName(key, [this](const QString &k) { return T(k); }));
}

void MainWindow::redo()
{
    if (redo_.empty()) return;
    history_.push_back(std::move(redo_.back()));
    redo_.pop_back();
    histIdx_ = static_cast<int>(history_.size()) - 1;
    showCurrent();
}

void MainWindow::updateButtons()
{
    undoBtn_->setEnabled(history_.size() > 1);
    redoBtn_->setEnabled(!redo_.empty());
    saveBtn_->setEnabled(histIdx_ >= 0);
}

void MainWindow::updateInfo()
{
    if (histIdx_ < 0) { infoLbl_->setText(QStringLiteral("—")); return; }
    const QImage &i = history_[histIdx_].img;
    infoLbl_->setText(QString("RGB  ·  %1  ·  px %2 × %3").arg(format_.isEmpty() ? "PNG" : format_).arg(i.width()).arg(i.height()));
}

// ============================================================================
//  Adjust tab
// ============================================================================
void MainWindow::onAdjustChanged()
{
    bVal_->setText(QString::number(brightSlider_->value()));
    cVal_->setText(QString::number(contrastSlider_->value()));
    if (histIdx_ < 0) return;
    cancelPending(false);
    const QImage &cur = history_[histIdx_].img;
    if (brightSlider_->value() == 0 && contrastSlider_->value() == 0) canvas_->setEdited(cur);
    else canvas_->setEdited(Filters::adjust(cur, brightSlider_->value(), contrastSlider_->value()));
}

void MainWindow::applyAdjust()
{
    if (histIdx_ < 0) { canvas_->showToast(T("t.noimage")); return; }
    const int b = brightSlider_->value(), c = contrastSlider_->value();
    if (b == 0 && c == 0) return;
    pushHistory("adjust", Filters::adjust(history_[histIdx_].img, b, c));
    canvas_->showToast(T("t.applied") + T("adjust"));
}

// ============================================================================
//  Running filters
// ============================================================================
void MainWindow::syncTiles()
{
    for (auto *t : tiles_) t->setChecked(t->filterId() == pendingId_);
}

// Clicking a filter only PREVIEWS it; nothing reaches the history until Apply.
void MainWindow::selectFilter(int id)
{
    if (histIdx_ < 0) { syncTiles(); canvas_->showToast(T("t.noimage")); return; }
    Params p;
    if (!askParams(id, p)) { syncTiles(); return; }
    QApplication::setOverrideCursor(Qt::WaitCursor);
    QImage out = applyFilter(id, p);
    QApplication::restoreOverrideCursor();
    if (out.isNull()) { syncTiles(); return; }
    pendingId_ = id;
    pendingParams_ = p;
    pendingImg_ = out;
    canvas_->setEdited(out);
    pendingLbl_->setText(T("pending") + T(QString("f%1").arg(id)));
    pendingBar_->show();
    syncTiles();
}

void MainWindow::applyPending()
{
    if (!pendingId_ || pendingImg_.isNull()) return;
    const int id = pendingId_;
    QImage img = pendingImg_;
    cancelPending(false);
    pushHistory(QString("f%1").arg(id), img);
    canvas_->showToast(T("t.applied") + T(QString("f%1").arg(id)));
}

void MainWindow::cancelPending(bool restoreCanvas)
{
    if (!pendingId_) return;
    pendingId_ = 0;
    pendingImg_ = QImage();
    pendingBar_->hide();
    syncTiles();
    if (restoreCanvas && histIdx_ >= 0) canvas_->setEdited(history_[histIdx_].img);
}

QImage MainWindow::applyFilter(int id, const Params &p) const
{
    const QImage &s = history_[histIdx_].img;
    switch (id) {
    case 1:  return Filters::greyscale(s);
    case 2:  return Filters::blackWhite(s);
    case 3:  return Filters::invert(s);
    case 4:  return Filters::frame(s, p.flag, p.a, p.color);
    case 5:  return Filters::flip(s, p.flag);
    case 6:  return Filters::rotate(s, p.a);
    case 7:  return Filters::brightnessLevel(s, p.flag, p.a);
    case 8:  return Filters::resize(s, p.a, p.b);
    case 9:  return Filters::merge(s, p.other, p.flag);
    case 10: return Filters::edges(s);
    case 11: return Filters::crop(s, p.a, p.b, p.c, p.d);
    case 12: return Filters::blur(s, 20);
    case 13: return Filters::sunlight(s);
    case 14: return Filters::oldTV(s);
    case 15: return Filters::purple(s);
    case 16: return Filters::infrared(s);
    case 17: return Filters::skew(s, p.angle);
    case 18: return Filters::oilPainting(s, 4, 20);
    }
    return QImage();
}

// Settings dialogs - mirror the cin prompts of the original console program.
bool MainWindow::askParams(int id, Params &p)
{
    if (id == 1 || id == 2 || id == 3 || id == 10 || id == 12 || id == 13 || id == 14 || id == 15 || id == 16 || id == 18) return true;

    const QImage &cur = history_[histIdx_].img;
    const int W = cur.width(), H = cur.height();

    QDialog dlg(this);
    dlg.setWindowTitle(T(QString("f%1").arg(id)));
    dlg.setLayoutDirection(ar_ ? Qt::RightToLeft : Qt::LeftToRight);
    dlg.setMinimumWidth(360);
    auto *vl = new QVBoxLayout(&dlg);
    vl->setContentsMargins(22, 22, 22, 18);
    vl->setSpacing(14);
    auto *form = new QFormLayout;
    form->setSpacing(12);
    vl->addLayout(form);

    auto runDialog = [&]() {
        auto *bb = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel);
        bb->button(QDialogButtonBox::Ok)->setText(T("ok"));
        bb->button(QDialogButtonBox::Cancel)->setText(T("cancel"));
        QObject::connect(bb, &QDialogButtonBox::accepted, &dlg, &QDialog::accept);
        QObject::connect(bb, &QDialogButtonBox::rejected, &dlg, &QDialog::reject);
        vl->addWidget(bb);
        return dlg.exec() == QDialog::Accepted;
    };

    switch (id) {
    case 4: { // Frame
        auto *type = new QComboBox;
        type->addItems({T("p.simple"), T("p.fancy")});
        auto *th = new QSpinBox;
        th->setRange(1, std::max(1, std::min(W, H) / 2));
        th->setValue(std::max(2, std::min(W, H) / 40));
        QColor col(Qt::white);
        auto *cb = new QPushButton;
        auto paint = [cb, &col] {
            cb->setText(col.name().toUpper());
            cb->setStyleSheet(QString("background:%1; color:%2; border:1px solid #2a3340;")
                                  .arg(col.name(), col.lightness() > 128 ? "#000" : "#fff"));
        };
        paint();
        QObject::connect(cb, &QPushButton::clicked, &dlg, [&] {
            QColor c = QColorDialog::getColor(col, &dlg);
            if (c.isValid()) { col = c; paint(); }
        });
        form->addRow(T("p.type"), type);
        form->addRow(T("p.thickness"), th);
        form->addRow(T("p.color"), cb);
        if (!runDialog()) return false;
        p.flag = type->currentIndex() == 1;
        p.a = th->value();
        p.color = col;
        return true;
    }
    case 5: { // Flip
        auto *dir = new QComboBox;
        dir->addItems({T("p.horizontal"), T("p.vertical")});
        form->addRow(T("p.direction"), dir);
        if (!runDialog()) return false;
        p.flag = dir->currentIndex() == 0;
        return true;
    }
    case 6: { // Rotate
        auto *deg = new QComboBox;
        deg->addItems({QString::fromUtf8("90°"), QString::fromUtf8("180°"), QString::fromUtf8("270°")});
        form->addRow(T("p.angle"), deg);
        if (!runDialog()) return false;
        p.a = (deg->currentIndex() + 1) * 90;
        return true;
    }
    case 7: { // Darken / Lighten
        auto *mode = new QComboBox;
        mode->addItems({T("p.darken"), T("p.lighten")});
        auto *lvl = new QSpinBox;
        lvl->setRange(0, 100);
        lvl->setValue(30);
        lvl->setSuffix("%");
        form->addRow(T("p.mode"), mode);
        form->addRow(T("p.level"), lvl);
        if (!runDialog()) return false;
        p.flag = mode->currentIndex() == 1;
        p.a = lvl->value();
        return true;
    }
    case 8: { // Resize
        auto *wS = new QSpinBox;
        wS->setRange(1, 20000);
        wS->setValue(W);
        auto *hS = new QSpinBox;
        hS->setRange(1, 20000);
        hS->setValue(H);
        auto *lock = new QCheckBox(T("p.ratio"));
        lock->setChecked(true);
        QObject::connect(wS, QOverload<int>::of(&QSpinBox::valueChanged), &dlg, [=](int v) {
            if (lock->isChecked()) { QSignalBlocker b(hS); hS->setValue(std::max(1, int(std::lround(double(v) * H / W)))); }
        });
        QObject::connect(hS, QOverload<int>::of(&QSpinBox::valueChanged), &dlg, [=](int v) {
            if (lock->isChecked()) { QSignalBlocker b(wS); wS->setValue(std::max(1, int(std::lround(double(v) * W / H)))); }
        });
        form->addRow(T("p.width"), wS);
        form->addRow(T("p.height"), hS);
        form->addRow(QString(), lock);
        if (!runDialog()) return false;
        p.a = wS->value();
        p.b = hS->value();
        return true;
    }
    case 9: { // Merge
        auto *path = new QLineEdit;
        auto *browse = new QPushButton(T("p.browse"));
        auto *row = new QWidget;
        auto *rl = new QHBoxLayout(row);
        rl->setContentsMargins(0, 0, 0, 0);
        rl->addWidget(path, 1);
        rl->addWidget(browse);
        QObject::connect(browse, &QPushButton::clicked, &dlg, [&] {
            QString f = QFileDialog::getOpenFileName(&dlg, T("p.second"), QString(), "Images (*.png *.jpg *.jpeg *.bmp *.tga *.gif)");
            if (!f.isEmpty()) path->setText(f);
        });
        auto *mode = new QComboBox;
        mode->addItems({T("p.biggest"), T("p.smallest")});
        form->addRow(T("p.second"), row);
        form->addRow(T("p.mode"), mode);
        if (!runDialog()) return false;
        QImage other(path->text());
        if (other.isNull()) { canvas_->showToast(T("t.loadfail")); return false; }
        p.other = other.convertToFormat(QImage::Format_RGB888);
        p.flag = mode->currentIndex() == 0;
        return true;
    }
    case 11: { // Crop
        auto *x = new QSpinBox; x->setRange(1, W); x->setValue(1);
        auto *y = new QSpinBox; y->setRange(1, H); y->setValue(1);
        auto *w = new QSpinBox; w->setRange(1, W); w->setValue(std::max(1, W / 2));
        auto *h = new QSpinBox; h->setRange(1, H); h->setValue(std::max(1, H / 2));
        form->addRow(T("p.x"), x);
        form->addRow(T("p.y"), y);
        form->addRow(T("p.width"), w);
        form->addRow(T("p.height"), h);
        if (!runDialog()) return false;
        p.a = x->value(); p.b = y->value(); p.c = w->value(); p.d = h->value();
        return true;
    }
    case 12: { // Blur
        auto *s = new QSpinBox;
        s->setRange(1, 60);
        s->setValue(10);
        form->addRow(T("p.strength"), s);
        if (!runDialog()) return false;
        p.a = s->value();
        return true;
    }
    case 17: { // Skew
        auto *a = new QDoubleSpinBox;
        a->setRange(-75, 75);
        a->setValue(20);
        a->setSuffix(QString::fromUtf8("°"));
        form->addRow(T("p.angle"), a);
        if (!runDialog()) return false;
        p.angle = a->value();
        return true;
    }
    case 18: { // Oil painting
        auto *r = new QSpinBox; r->setRange(1, 8); r->setValue(4);
        auto *l = new QSpinBox; l->setRange(4, 64); l->setValue(20);
        form->addRow(T("p.radius"), r);
        form->addRow(T("p.levels"), l);
        if (!runDialog()) return false;
        p.a = r->value();
        p.b = l->value();
        return true;
    }
    }
    return true;
}
