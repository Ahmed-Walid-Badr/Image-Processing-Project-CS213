cmake_minimum_required(VERSION 4.1)
project(Source_Code)

set(CMAKE_CXX_STANDARD 14)

include_directories(.)

add_executable(Source_Code
        Image_Class.h
        Source_Code.cpp
        stb_image.h
        stb_image_write.h)
